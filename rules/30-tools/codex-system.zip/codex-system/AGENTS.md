# 项目指令（本仓库）

> 位置：`<repo>/AGENTS.md`。进版本控制，随 Git 同步到两台 Mac。
> 继承 `~/.codex/AGENTS.md` 的全局规则，此处只写本项目特有内容。
> 目标行数 < 150，每个 token 每轮都会被加载，保持信号密度。

## 项目背景
- <一句话说明这个项目是什么、技术栈是什么>
- 例：Python + FastAPI 后端，PostgreSQL，pnpm 管理前端。

## 本项目约束
- <该项目特有的硬规则，如"新端点必须配集成测试">
- <命名/目录/提交约定>

## 任务前加载（按需，不要全量）
1. 读 `state/runtime.md` —— 当前任务、阶段、下一步、阻塞项。
2. 若与当前输入相关，再读 `state/tasks.md`、`state/progress.md`。
3. 需要长期背景或过往决策时，才 `cat` 对应的 `memory/*.md`、`decisions/*.md`。
4. 需要复盘某天对话时，才读 `sessions/YYYY-MM-DD.md`。
   —— sessions 和 memory 会持续增长，切勿每轮全量读入。

## 任务后落盘
- 状态变化 → 更新 `state/runtime.md` / `tasks.md` / `progress.md`。
- 关键决策 → 追加 `decisions/architecture.md`（含时间戳）。
- 方案取舍 → 追加 `decisions/tradeoffs.md`。
- 用户偏好变化 → 追加 `memory/user-preferences.md`。
- 本次会话摘要 → 追加 `sessions/<今日>.md`（追加，不覆盖）。
- 完成后提示用户运行 `python3 tools/sync.py`。

## 双 Mac 纪律
- 开工前 `git pull --rebase`；收工 `python3 tools/sync.py`。
- 两台机只用 main 分支，避免分叉。
