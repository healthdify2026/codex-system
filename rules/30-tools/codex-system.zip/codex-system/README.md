# Codex Engineering Auto-Sync System v3.1

在两台 MacBook 之间，用 Git 同步 Codex 项目的"工程状态"（而非聊天记录）。

## 它做什么 / 不做什么

- ✅ 同步：项目代码、长期记忆、当前状态、任务、决策、会话摘要。
- ❌ 不做：同步 Codex CLI 本地的原始对话历史（那存在 `~/.codex/`，不进本仓库）。
  取而代之，每次对话的**结论**由 Codex 结构化写入本仓库文件，再靠 Git 同步。

## 目录结构

```
prompts/     Codex 行为与提示词规则
memory/      长期记忆（global / user-preferences / project-context）
state/       当前状态（runtime / tasks / progress）
decisions/   关键决策（architecture / tradeoffs / changelog）
sessions/    对话归档，按日期 YYYY-MM-DD.md
tools/       自动化脚本
src/         真实项目代码
AGENTS.md    Codex CLI 自动加载的入口
codex.config.json
```

## 双 Mac 同步

首台机器：
```bash
python tools/init_project.py
git init && git add . && git commit -m "init codex system"
git remote add origin <your-repo-url>
git branch -M main && git push -u origin main
```

第二台机器：
```bash
git clone <your-repo-url> && cd codex-system
```

日常纪律（两台都一样）：
```bash
git pull --rebase        # 开工前
# ... 用 Codex 干活 ...
python tools/sync.py     # 收工时（内部会 pull --rebase 后再 push）
```

## 常用命令

```bash
python tools/run.py                      # 主入口：检查结构 + 读上下文
python tools/run.py --input "对话内容"    # 解析一段对话并落盘
python tools/run.py --file ./input.md    # 从文件读入对话
python tools/run.py --sync               # 执行完顺带同步
python tools/sync.py                     # 单独执行 Git 同步
bash tools/install_hooks.sh              # 安装 git hooks（可选）
```

## Git 冲突处理

`sync.py` 遇到冲突会中止并提示。手动处理：
```bash
git status                 # 看冲突文件
# 编辑解决冲突标记 <<<< ==== >>>>
git add <文件> && git rebase --continue
git push
```

## 注意

- 不要把 memory/ state/ decisions/ sessions/ 加进 .gitignore——那正是要同步的"项目大脑"。
- 两台机器请用同一分支（main），避免分叉。
