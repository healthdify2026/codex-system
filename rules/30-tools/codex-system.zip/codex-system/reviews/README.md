# reviews/ — 任务验收单

每个任务一份 `<任务ID>.md`，由 REVIEW.template.md 复制填写。
Codex 执行后填「自检」→ 用户带回 → Claude 填「审核结论」。
与 specs/ 下同名文件配对，构成一次完整的规划-执行-审核闭环。
