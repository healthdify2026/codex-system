# 无人值守自动化：specs → Codex → 自审 → sync

消除手动搬运。你（或 Claude 通过 Git）往 `specs/` 放一份 SPEC，机器自动执行、自审、通过则同步；卡住才等你抽查。

## 角色

- **规划者 Claude**：写 `specs/<ID>.md`（含验收 checklist），通过 Git 异步交付。
- **执行者 + 审核者**：都由本机 `codex exec` 扮演。orchestrator 先让 Codex 执行，再让 Codex 以审核 agent 身份对照 checklist 打分。
- **你**：只在 ESCALATE（重试耗尽仍不过）时介入抽查。日常无需搬运。

> 诚实说明：自动化后，实时"审核"由 Codex 自己完成，Claude 不在运行循环里。
> Claude 的价值前移到"把 SPEC 和验收标准定清楚"。REVIEW 全部留档在 `reviews/`，
> 你可随时 `git pull` 抽查，这就是"自动+抽查"模式。

## 组件

- `tools/orchestrator.py` — 执行一个 SPEC 的完整闭环（执行→自审→通过/重试/升级）。
- `tools/watch_specs.py` — 轮询 `specs/`，发现新的或改动过的 SPEC 就调 orchestrator。
- `docs/com.codex.watch.plist` — 让 watcher 后台常驻（launchd）。

## 前置

1. 装好并登录 Codex CLI（`codex --version` 可用）。自动化建议用 `CODEX_API_KEY`。
2. 仓库是 git 仓库（orchestrator/sync 依赖 git）。
3. 配好远程 origin（sync 要 push）。

## 手动跑一个 SPEC

```bash
python3 tools/orchestrator.py specs/2026-07-02-sync-dryrun.md
# 指定权限级别：
python3 tools/orchestrator.py --sandbox read-only specs/<ID>.md
```

## 开启监听（免搬运）

前台试跑：
```bash
python3 tools/watch_specs.py --sandbox workspace-write
```
只扫一次（配合 cron）：
```bash
python3 tools/watch_specs.py --once
```
后台常驻：编辑 `docs/com.codex.watch.plist` 里的路径，然后
```bash
cp docs/com.codex.watch.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.codex.watch.plist
```

## sandbox 权限级别（orchestrator --sandbox）

- `read-only`：只读，只给建议不改文件。最保守，适合分析/审查类。
- `workspace-write`：可改工作区文件、默认不联网不碰仓库外。**推荐默认**，适合改代码。
- `danger-full-access`：无沙箱，仅隔离容器/CI 用，本地日常勿用。

## 判定与出口

- **PASS**：自审全过 → 写 `reviews/<ID>.md` → `sync.py` 同步。
- **RETRY**：有条目未过 → 把具体条目回喂 Codex 重做（最多 `MAX_RETRY` 次）。
- **ESCALATE**：重试耗尽仍不过 → 停手，`reviews/<ID>.md` 打上「需人工抽查」→ 等你介入。

## 抽查怎么做

定期或收到 ESCALATE 时：
```bash
git pull --rebase
ls reviews/                       # 看各任务判定
grep -l "ESCALATE" reviews/*.md   # 找出需人工复核的
git log --oneline -10             # 看机器都自动提交了什么
```
把某个 `reviews/<ID>.md` 连同 `git show <commit>` 的 diff 贴给 Claude，即可人工复核。

## 边界与风险

- 自动化不替你解决 git 冲突：`sync.py` 遇冲突会中止，留给你手动处理。
- Codex 自审可能"自我宽容"：验收 checklist 要尽量写**可客观核验的证据要求**
  （如"贴出测试命令输出""diff 只含某文件"），降低自评虚高的风险。
- 每台 Mac 各自跑一个 watcher；`state/.processed_specs.json` 是本机状态、不入 Git，
  避免两台机重复处理同一 SPEC。真正的协调仍靠 Git（谁先 push 谁的产出为准）。
- 建议先用 `read-only` 跑几个 SPEC 观察 Codex 行为，再放开到 `workspace-write`。
