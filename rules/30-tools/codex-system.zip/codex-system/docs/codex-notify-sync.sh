#!/bin/bash
# ~/.codex/codex-notify-sync.sh  (v2, 带防抖)
# 由 Codex 的 notify 机制在每轮任务完成时调用。
# 仅当当前目录是受管 codex-system 仓库时行动。
#
# 由项目 codex.config.json 的 auto_sync 决定：
#   false（默认）：只提示，不提交。
#   true          ：防抖后自动 pull--rebase / commit / push。
# 防抖：连续活跃期内不提交，空闲超过 DEBOUNCE 秒的一轮才真正 sync，
#       避免把一次连续工作打成很多碎提交。

set -euo pipefail
DEBOUNCE=180   # 秒

EVENT_JSON="${1:-}"
CWD=""
if command -v python3 >/dev/null 2>&1 && [ -n "$EVENT_JSON" ]; then
  CWD=$(python3 -c "import sys,json
try:
    print(json.loads(sys.argv[1]).get('cwd',''))
except Exception:
    print('')" "$EVENT_JSON" 2>/dev/null || true)
fi
[ -z "$CWD" ] && CWD="$(pwd)"
cd "$CWD" 2>/dev/null || exit 0

if [ ! -d .git ] || [ ! -f codex.config.json ] || [ ! -f tools/sync.py ]; then
  exit 0
fi
if [ -z "$(git status --porcelain)" ]; then
  exit 0
fi

AUTO=$(python3 -c "import json;print(json.load(open('codex.config.json')).get('auto_sync',False))" 2>/dev/null || echo False)
if [ "$AUTO" != "True" ]; then
  echo "🔔 有未提交变更，收工时运行： python3 tools/sync.py"
  exit 0
fi

STAMP=".git/.codex-sync-stamp"
NOW=$(date +%s)
if [ -f "$STAMP" ]; then
  LAST=$(cat "$STAMP" 2>/dev/null || echo 0)
  if [ $((NOW - LAST)) -lt "$DEBOUNCE" ]; then
    echo "$NOW" > "$STAMP"
    exit 0
  fi
fi
echo "$NOW" > "$STAMP"
python3 tools/sync.py
