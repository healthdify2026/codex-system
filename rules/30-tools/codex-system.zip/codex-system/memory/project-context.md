# Project Context

> 项目背景与上下文。

## 2026-07-02 03:14
- 目标：在两台 MacBook 之间建立工程级 Codex 项目与状态同步。

## 2026-07-02 03:40
- 部署方式：~/.codex/ 层每台 Mac 各配一次（不入 Git）；项目层 AGENTS.md 放仓库根，随 clone 同步。
- project-repo/ 仅为打包分类容器，其内文件应平铺到仓库根，目录名不带入。
- AGENTS.override.md 为本机临时覆盖，已 gitignore，不同步。
