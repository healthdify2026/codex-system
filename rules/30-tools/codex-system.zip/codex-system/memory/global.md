# Global Memory

> 全局长期记忆。不可随意删除。追加式维护。

## 2026-07-02 03:14
- 建立 Codex Engineering Auto-Sync System v3.1。
- Git 作为双 Mac 同步的唯一事实源。

## 2026-07-02 03:40
- Codex 同步系统定型：Git 唯一事实源 + AGENTS.md 三层 + 上下文分层加载 + notify 同步。
- 不同步聊天原始记录（在 ~/.codex/，不入库）；同步的是结构化落盘的结论。

## 2026-07-02 07:20
- 工作模式定型：Claude 只规划与审核，Codex 执行。产物是 specs/(规格单) 与 reviews/(验收单) 配对，靠用户手动搬运衔接。
