# Tradeoffs

## 2026-07-02 03:14
- 权衡：sync.py 采用 pull --rebase 优先，牺牲一点"总能自动提交"的顺滑度，
  换取避免双机互相覆盖与减少合并噪音。

## 2026-07-02 03:40
- 权衡：拒绝用 iCloud 同步 codex-system。iCloud 会对 .git/ 做按需驱逐导致仓库损坏，且与 Git 形成双同步引擎抢写、产生冲突副本、时机不可控。牺牲"零命令自动同步"的便利，换取仓库完整性与可控性；便利性由 git alias + notify 补回。
- 权衡：Desktop 的后台 Automations 也读同一套 AGENTS.md，可能触发非预期的 push。取舍：保持项目 codex.config.json 的 auto_sync=false，notify 脚本仅提示不提交，牺牲全自动换取提交语义清晰。

## 2026-07-02 07:35
- 权衡：审核环从"Claude 手动审"改为"Codex 自审"，换取完全免搬运；代价是丧失 Claude 的实时把关，靠 checklist 写足客观证据要求 + 事后抽查 + ESCALATE 出口来补偿。
- 权衡：用轮询而非文件系统事件(watchdog)，牺牲即时性(默认20s延迟)换取零第三方依赖、跨机一致。
