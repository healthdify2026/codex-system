# Changelog

## 2026-07-02 03:14
- 初始化 Codex Engineering Auto-Sync System v3.1。

## 2026-07-02 03:40
- 定稿 AGENTS.md 三层结构、上下文分层加载、notify 同步方案；否决 iCloud 同步。
- run.py 改为分层加载；根 AGENTS.md 换为按需版；新增 AGENTS.override.md.example 并 gitignore。
