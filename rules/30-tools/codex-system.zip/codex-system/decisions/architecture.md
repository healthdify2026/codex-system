# Architecture Decisions

## 2026-07-02 03:14
- 类型：DECISION
- 内容：采用 Git 作为 Codex 双 Mac 同步的唯一事实源。
- 类型：DECISION
- 内容：使用根目录 AGENTS.md 作为 Codex 上下文加载入口（Codex CLI 自动读取该文件）。

## 2026-07-02 03:14
- 类型：DECISION
- 内容：我们决定采用 PostgreSQL 作为主数据库

## 2026-07-02 03:40
- 类型：DECISION
- 内容：AGENTS.md 采用 Codex 原生三层机制（~/.codex/AGENTS.md 全局 / <repo>/AGENTS.md 项目 / AGENTS.override.md 本机临时），不自建分层。优先级 override > AGENTS.md > 回退文件，就近覆盖。
- 类型：DECISION
- 内容：全局层只放跨项目稳定"规则"，绝不放项目"记忆/状态"；记忆随 Git 存项目仓库。
- 类型：DECISION
- 内容：上下文分层加载——默认每轮只读规则 + state/runtime.md（约5个文件），memory/ 与 sessions/ 改为按需 cat，不全量灌入。依据：手写精简指令可降 bug 35–55%，冗长文件反增成本约20%。
- 类型：DECISION
- 内容：CLI 与 Desktop 共享同一套 ~/.codex/config.toml 与项目 AGENTS.md，无需额外配置即一致生效（Codex 多表面单系统架构）。
- 类型：DECISION
- 内容：同步时机用 config.toml 的 notify（agent-turn-complete）触发 codex-notify-sync.sh，代替 iCloud；默认只提示不自动提交，auto_sync=false。

## 2026-07-02 07:20
- 类型：DECISION
- 内容：确立三段式协作工作流（Workflow 5）——Claude 规划(写 SPEC+验收checklist) / Codex 执行(按SPEC+填REVIEW自检) / Claude 审核(对照checklist核验)。衔接方式：用户手动搬运 SPEC 与 REVIEW/diff。验收基准：预先定义的 checklist（Definition of Done），非事后主观评审。
- 类型：DECISION
- 内容：SPEC 含"范围内/范围外/约束/验收checklist/交付物"五要素；Codex 执行时只做范围内、遇冲突或缺信息停下报告、不擅自扩张或猜测。审核打回须指明未满足的具体 checklist 条目。

## 2026-07-02 07:35
- 类型：DECISION
- 内容：新增无人值守自动化层——watch_specs.py 监听 specs/，orchestrator.py 用 codex exec 执行+自审(第二次 exec 扮审核agent，--output-schema 约束结构化打分)，PASS→sync/RETRY→回喂重做/ESCALATE→停手留档。消除手动搬运。
- 类型：DECISION
- 内容：采用"自动+抽查"——机器自审自过为默认路径，Claude 退为标准制定者(写SPEC+checklist)，不在实时循环内；ESCALATE 是唯一人工介入出口，REVIEW 全程留档供 git pull 抽查。
- 类型：DECISION
- 内容：触发方式为监听 specs/(轮询，无 watchdog 依赖)；处理去重靠 state/.processed_specs.json(本机状态，不入 Git)；权限默认 workspace-write，脚本注释三档供选。
