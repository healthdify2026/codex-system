# SPEC — 给 sync.py 增加 --dry-run 选项

- 任务 ID：2026-07-02-sync-dryrun
- 关联决策：decisions/tradeoffs.md（sync 采用 pull --rebase 优先）
- 创建时间：2026-07-02

## 目标
让用户能预览 sync.py 将执行的 git 操作而不真正提交/推送，降低自动同步的心理负担。

## 范围内（必须做）
- 在 tools/sync.py 增加 `--dry-run` 命令行参数。
- 带该参数时，打印将要执行的每条 git 命令，但不实际运行会改变状态的命令（commit/push）。
- pull 只读，可照常执行或一并跳过（二选一，在 REVIEW 说明选择）。

## 范围外（明确不做）
- 不改动防抖脚本 codex-notify-sync.sh。
- 不改变 auto_sync 的默认值。
- 不引入新的第三方依赖。

## 约束
- 遵守本仓库 AGENTS.md 规则。
- 保持 sync.py 现有行为在不带 --dry-run 时完全不变（向后兼容）。
- 纯标准库实现（argparse 已在用）。

## 验收 checklist（Definition of Done）
- [ ] 1. `python3 tools/sync.py --dry-run` 能运行且不产生任何 commit/push。
- [ ] 2. dry-run 模式下逐条打印将执行的 git 命令，带明显的 [DRY-RUN] 标记。
- [ ] 3. 不带 --dry-run 时行为与改动前完全一致（向后兼容）。
- [ ] 4. `python3 -c "import ast;ast.parse(open('tools/sync.py').read())"` 语法通过。
- [ ] 5. git diff 仅改动 tools/sync.py，无范围外文件变更。

## 交付物
- tools/sync.py（新增 --dry-run 分支）
- reviews/2026-07-02-sync-dryrun.md（自检单）
