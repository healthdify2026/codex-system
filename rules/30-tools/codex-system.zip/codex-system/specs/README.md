# specs/ — 任务规格单

每个任务一份 `<任务ID>.md`，由 SPEC.template.md 复制填写。
规划者（Claude）填写 → 用户整份贴给 Codex 执行。
命名：`YYYY-MM-DD-简短名.md`，与 reviews/ 下同名文件配对。
