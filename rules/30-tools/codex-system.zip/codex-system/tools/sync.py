#!/usr/bin/env python3
"""Git 同步器：pull --rebase 优先，冲突则中止提示。"""
import subprocess
import sys
from datetime import datetime

def run(cmd, check=True):
    print("+", " ".join(cmd))
    return subprocess.run(cmd, capture_output=True, text=True)

def main():
    # 无变更也不报错
    status = run(["git", "status", "--porcelain"])
    # 检测是否已配置上游远程
    has_upstream = run(["git", "rev-parse", "--abbrev-ref",
                        "--symbolic-full-name", "@{u}"]).returncode == 0
    if has_upstream:
        pull = run(["git", "pull", "--rebase"])
        print(pull.stdout, pull.stderr)
        if "CONFLICT" in (pull.stdout + pull.stderr):
            print("\n⚠️  拉取时发生冲突，已中止自动提交。请手动解决：")
            print("   git status → 编辑冲突文件 → git add → git rebase --continue → git push")
            sys.exit(1)
        if pull.returncode != 0:
            print("\n⚠️  git pull 失败（非冲突），已中止。请检查网络/远程后重试。")
            sys.exit(1)
    else:
        print("（尚未配置上游远程，跳过 pull；请配置 origin 后 push。）")

    if not status.stdout.strip():
        print("无本地变更，跳过提交。")
        # 仍尝试 push（可能本地领先远端）
        run(["git", "push"])
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    run(["git", "add", "."])
    run(["git", "commit", "-m", f"codex auto sync: {ts}"])
    push = run(["git", "push"])
    print(push.stdout, push.stderr)
    if push.returncode != 0:
        print("⚠️  push 失败，请检查远程仓库与网络。")
        sys.exit(1)
    print("✅ 同步完成。")

if __name__ == "__main__":
    main()
