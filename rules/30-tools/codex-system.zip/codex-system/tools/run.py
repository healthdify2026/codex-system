#!/usr/bin/env python3
"""主入口：检查结构 → 读上下文 → (可选)解析对话落盘 → 更新状态 → (可选)同步。"""
import argparse
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

import chat_parser
import memory_extractor
import state_engine

CONTEXT = ["prompts", "memory", "state", "decisions"]

def ensure_structure():
    missing = [d for d in CONTEXT + ["sessions", "tools"]
               if not os.path.isdir(os.path.join(ROOT, d))]
    if missing:
        print("缺少目录:", missing, "→ 请先运行 python tools/init_project.py")
        sys.exit(1)

def load_context():
    # 分层加载：默认只读稳定规则 + 当前状态摘要，避免每轮全量灌入 memory/sessions
    print("== 默认加载（每轮）==")
    always = ["AGENTS.md", "prompts/system.md", "prompts/agent.md",
              "prompts/workflows.md", "state/runtime.md"]
    for rel in always:
        if os.path.exists(os.path.join(ROOT, rel)):
            print(f"  read {rel}")

    # 其余仅列出清单，供 Codex 判断后按需读取，不主动灌入上下文
    print("== 按需可读（不自动加载）==")
    for d in ["memory", "decisions", "sessions", "state"]:
        p = os.path.join(ROOT, d)
        if os.path.isdir(p):
            for fn in sorted(os.listdir(p)):
                rel = f"{d}/{fn}"
                if fn.endswith(".md") and rel not in always:
                    print(f"  available {rel}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", help="直接传入对话内容")
    ap.add_argument("--file", help="从文件读入对话内容")
    ap.add_argument("--sync", action="store_true", help="结束后执行 git 同步")
    args = ap.parse_args()

    ensure_structure()
    load_context()

    text = ""
    if args.input:
        text = args.input
    elif args.file:
        with open(args.file, encoding="utf-8") as f:
            text = f.read()

    if text.strip():
        items = chat_parser.parse(text)
        touched = memory_extractor.extract(items)
        print("== 落盘 ==", sorted(touched))

    state_engine.touch_runtime()
    print("== 状态已更新 ==")

    if args.sync:
        subprocess.run([sys.executable, os.path.join(ROOT, "tools", "sync.py")])

if __name__ == "__main__":
    main()
