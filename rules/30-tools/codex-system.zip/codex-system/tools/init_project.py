#!/usr/bin/env python3
"""
Codex Engineering Auto-Sync System v3.1 — 一键初始化脚本

用法:
    python init_project.py            # 在当前目录初始化
    python init_project.py ./codex-system   # 在指定目录初始化

生成完整目录结构、prompts、memory、state、decisions、sessions、
tools 下全部自动化脚本、AGENTS.md、codex.config.json、README、.gitignore。
幂等：已存在的文件不会被覆盖（除非用 --force）。
"""

import os
import sys
import stat
from datetime import datetime

FORCE = "--force" in sys.argv
ARGS = [a for a in sys.argv[1:] if not a.startswith("-")]
ROOT = os.path.abspath(ARGS[0]) if ARGS else os.getcwd()

NOW = datetime.now().strftime("%Y-%m-%d %H:%M")
TODAY = datetime.now().strftime("%Y-%m-%d")

DIRS = [
    "prompts", "memory", "state", "decisions", "sessions", "tools", "src",
]

# ---------------------------------------------------------------------------
# 文件内容
# ---------------------------------------------------------------------------

FILES = {}

# ---- AGENTS.md (Codex CLI 真正自动加载的入口) ----
FILES["AGENTS.md"] = f"""# AGENTS.md — Codex 工程执行入口

> Codex CLI 启动时会自动读取本文件。这是整套系统的真正入口，
> 因为 Codex 不会自动读取 prompts/ 或 memory/，必须由本文件显式指令。

## 每次任务前，你必须先读取以下上下文（按顺序）

1. `prompts/system.md`  — 全局系统规则（最高优先级）
2. `prompts/agent.md`   — Agent 执行规则
3. `prompts/workflows.md` — 工作流定义
4. `memory/*.md`        — 长期记忆、用户偏好、项目背景
5. `state/*.md`         — 当前运行状态、任务、进度
6. `decisions/*.md`     — 架构决策、权衡、变更日志

读取完成后，再判断当前用户任务与已有状态是否冲突，然后执行。

## 每次任务后，你必须

1. 更新 `state/runtime.md`、`state/tasks.md`、`state/progress.md`（如有变化）。
2. 将关键决策写入 `decisions/`。
3. 将用户偏好变化写入 `memory/user-preferences.md`。
4. 将本次会话摘要写入 `sessions/{{today}}.md`（追加，不覆盖）。
5. 提醒用户运行 `python tools/sync.py` 提交同步（除非 auto_sync 开启）。

## 核心原则

- Git 是唯一事实源。状态存文件，不存对话。
- 不依赖"我会记住"。所有长期价值内容必须落盘。
- 输出：结论优先，命令可直接执行，文件变更明确。

## 双 Mac 工作纪律

开始工作前先 `git pull --rebase`；完成后 `python tools/sync.py`。
"""

FILES["prompts/system.md"] = """# Codex System Rules

你是 Codex 工程执行引擎。

## 核心身份

你负责在本地项目中执行工程任务，包括读取上下文、更新文件、维护状态、记录决策和同步 Git。

## 强制规则

1. 你不依赖聊天历史作为事实源。
2. 所有长期记忆来自 `memory/`。
3. 所有当前状态来自 `state/`。
4. 所有关键决策来自 `decisions/`。
5. 所有会话摘要必须写入 `sessions/`。
6. Git 是唯一事实源。
7. 每次执行任务前必须读取 `prompts/`、`memory/`、`state/`、`decisions/`。
8. 每次执行任务后必须更新状态文件。
9. 如果产生关键决策，必须写入 `decisions/`。
10. 如果用户偏好发生变化，必须写入 `memory/user-preferences.md`。

## 输出要求

- 结论优先。
- 步骤清晰。
- 命令可执行。
- 文件变更明确。
- 不使用空泛表述。
- 不承诺无法保证的后台同步。
"""

FILES["prompts/agent.md"] = """# Codex Agent Rules

## 执行前

1. 读取项目结构。
2. 读取 prompts。
3. 读取 memory。
4. 读取 state。
5. 读取 decisions。
6. 确定当前任务。
7. 检查是否存在冲突。

## 执行中

- 优先修改文件，而不是只输出建议。
- 涉及工程任务时，必须给出可运行代码或直接创建文件。
- 涉及架构变化时，必须记录决策。
- 涉及任务变化时，必须更新 state。

## 执行后

必须输出：

1. 本次完成了什么。
2. 修改了哪些文件。
3. 当前状态是什么。
4. 下一步建议是什么。
"""

FILES["prompts/workflows.md"] = """# Codex Workflows

## Workflow 1: 初始化项目
触发：项目目录不存在或用户要求初始化。
步骤：创建目录 → 生成默认文件 → 生成 tools 脚本 → 生成 README/配置 → git init。

## Workflow 2: 日常任务执行
触发：用户给出任务。
步骤：读取上下文 → 分析任务 → 修改文件 → 更新 state → 写入 session → 视情况提交 Git。

## Workflow 3: 对话归档
触发：用户提供重要对话，或本次任务产生重要结论。
步骤：解析对话 → 提取记忆/状态/决策 → 写入 sessions → 更新 memory/state/decisions。

## Workflow 4: 双 Mac 同步
触发：用户在任一 Mac 开始工作。
步骤：git pull --rebase → 执行任务 → 更新状态 → git add → git commit → git push → 另一台 git pull --rebase。
"""

FILES["memory/global.md"] = f"""# Global Memory

> 全局长期记忆。不可随意删除。追加式维护。

## {NOW}
- 建立 Codex Engineering Auto-Sync System v3.1。
- Git 作为双 Mac 同步的唯一事实源。
"""

FILES["memory/user-preferences.md"] = f"""# User Preferences

> 用户偏好与协作风格。

## {NOW}
- 输出风格：结论优先，命令可直接执行，不写空泛口号。
"""

FILES["memory/project-context.md"] = f"""# Project Context

> 项目背景与上下文。

## {NOW}
- 目标：在两台 MacBook 之间建立工程级 Codex 项目与状态同步。
"""

FILES["state/runtime.md"] = f"""# Runtime State

## 当前任务
- 初始化 Codex Engineering Auto-Sync System

## 当前阶段
- 系统初始化完成

## 下一步
- 配置 Git 远程仓库并在第二台 Mac clone

## 阻塞项
- 暂无

## 最近更新时间
- {NOW}
"""

FILES["state/tasks.md"] = """# Tasks

## To Do
- [ ] 配置 Git 远程仓库
- [ ] 在第二台 Mac clone 并验证

## Doing
- [ ] 无

## Done
- [x] 初始化标准目录结构
- [x] 生成自动化脚本
"""

FILES["state/progress.md"] = """# Progress

## 当前进度
- v3.1 系统初始化完成

## 已完成
- 标准目录结构
- prompts / memory / state / decisions
- tools 自动化脚本
- AGENTS.md 入口

## 未完成
- Git 远程仓库配置
- 第二台 Mac 验证
"""

FILES["decisions/architecture.md"] = f"""# Architecture Decisions

## {NOW}
- 类型：DECISION
- 内容：采用 Git 作为 Codex 双 Mac 同步的唯一事实源。
- 类型：DECISION
- 内容：使用根目录 AGENTS.md 作为 Codex 上下文加载入口（Codex CLI 自动读取该文件）。
"""

FILES["decisions/tradeoffs.md"] = f"""# Tradeoffs

## {NOW}
- 权衡：sync.py 采用 pull --rebase 优先，牺牲一点"总能自动提交"的顺滑度，
  换取避免双机互相覆盖与减少合并噪音。
"""

FILES["decisions/changelog.md"] = f"""# Changelog

## {NOW}
- 初始化 Codex Engineering Auto-Sync System v3.1。
"""

FILES[f"sessions/{TODAY}.md"] = f"""# Session {TODAY}

## {NOW}
- 类型：SESSION
- 内容：初始化系统。生成目录结构、prompts、memory、state、decisions、tools 脚本。
"""

FILES["codex.config.json"] = """{
  "version": "3.1",
  "source_of_truth": "git",
  "context_dirs": ["prompts", "memory", "state", "decisions"],
  "session_dir": "sessions",
  "tools_dir": "tools",
  "auto_sync": false,
  "write_session_summary": true,
  "update_state_after_task": true,
  "rules": {
    "do_not_depend_on_chat_history": true,
    "read_context_before_task": true,
    "record_decisions": true,
    "record_user_preferences": true,
    "git_as_single_source_of_truth": true
  }
}
"""

FILES[".gitignore"] = """.DS_Store
__pycache__/
*.pyc
.env
.venv/
venv/
node_modules/
*.log
"""

FILES["README.md"] = """# Codex Engineering Auto-Sync System v3.1

在两台 MacBook 之间，用 Git 同步 Codex 项目的"工程状态"（而非聊天记录）。

## 它做什么 / 不做什么

- ✅ 同步：项目代码、长期记忆、当前状态、任务、决策、会话摘要。
- ❌ 不做：同步 Codex CLI 本地的原始对话历史（那存在 `~/.codex/`，不进本仓库）。
  取而代之，每次对话的**结论**由 Codex 结构化写入本仓库文件，再靠 Git 同步。

## 目录结构

```
prompts/     Codex 行为与提示词规则
memory/      长期记忆（global / user-preferences / project-context）
state/       当前状态（runtime / tasks / progress）
decisions/   关键决策（architecture / tradeoffs / changelog）
sessions/    对话归档，按日期 YYYY-MM-DD.md
tools/       自动化脚本
src/         真实项目代码
AGENTS.md    Codex CLI 自动加载的入口
codex.config.json
```

## 双 Mac 同步

首台机器：
```bash
python tools/init_project.py
git init && git add . && git commit -m "init codex system"
git remote add origin <your-repo-url>
git branch -M main && git push -u origin main
```

第二台机器：
```bash
git clone <your-repo-url> && cd codex-system
```

日常纪律（两台都一样）：
```bash
git pull --rebase        # 开工前
# ... 用 Codex 干活 ...
python tools/sync.py     # 收工时（内部会 pull --rebase 后再 push）
```

## 常用命令

```bash
python tools/run.py                      # 主入口：检查结构 + 读上下文
python tools/run.py --input "对话内容"    # 解析一段对话并落盘
python tools/run.py --file ./input.md    # 从文件读入对话
python tools/run.py --sync               # 执行完顺带同步
python tools/sync.py                     # 单独执行 Git 同步
bash tools/install_hooks.sh              # 安装 git hooks（可选）
```

## Git 冲突处理

`sync.py` 遇到冲突会中止并提示。手动处理：
```bash
git status                 # 看冲突文件
# 编辑解决冲突标记 <<<< ==== >>>>
git add <文件> && git rebase --continue
git push
```

## 注意

- 不要把 memory/ state/ decisions/ sessions/ 加进 .gitignore——那正是要同步的"项目大脑"。
- 两台机器请用同一分支（main），避免分叉。
"""

# ---------------------------------------------------------------------------
# tools/ 脚本
# ---------------------------------------------------------------------------

FILES["tools/chat_parser.py"] = '''#!/usr/bin/env python3
"""对话解析器：把一段文本按启发式规则切分为结构化条目。"""
import re

RULES = [
    ("DECISION",  ["决定", "确定", "采用", "选择", "以后统一", "后续都"]),
    ("BLOCKER",   ["问题", "阻塞", "风险", "报错", "失败"]),
    ("TRADEOFF",  ["原因", "取舍", "权衡", "优缺点"]),
    ("PROGRESS",  ["完成", "进度", "已实现", "还没做"]),
    ("PREFERENCE",["偏好", "希望", "默认", "风格"]),
    ("TASK",      ["当前", "正在", "这次", "下一步", "待办", "任务"]),
]

def classify(line: str) -> str:
    for label, kws in RULES:
        if any(k in line for k in kws):
            return label
    return "FACT"

def parse(text: str):
    items = []
    for raw in re.split(r"[\\n。；;]", text):
        s = raw.strip()
        if not s:
            continue
        items.append({"type": classify(s), "content": s})
    return items

if __name__ == "__main__":
    import sys, json
    data = sys.stdin.read() if not sys.stdin.isatty() else ""
    print(json.dumps(parse(data), ensure_ascii=False, indent=2))
'''

FILES["tools/memory_extractor.py"] = '''#!/usr/bin/env python3
"""记忆提取器：将解析结果追加写入对应文件（带时间戳）。"""
import os
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOW = datetime.now().strftime("%Y-%m-%d %H:%M")
TODAY = datetime.now().strftime("%Y-%m-%d")

TARGET = {
    "FACT":       "memory/global.md",
    "PREFERENCE": "memory/user-preferences.md",
    "DECISION":   "decisions/architecture.md",
    "TRADEOFF":   "decisions/tradeoffs.md",
    "PROGRESS":   "state/progress.md",
    "BLOCKER":    "state/runtime.md",
    "TASK":       "state/tasks.md",
}

def append(path: str, block: str):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "a", encoding="utf-8") as f:
        f.write(block)

def extract(items):
    touched = set()
    session_lines = []
    for it in items:
        t, c = it["type"], it["content"]
        path = TARGET.get(t, "memory/global.md")
        append(path, f"\\n## {NOW}\\n- 类型：{t}\\n- 内容：{c}\\n")
        touched.add(path)
        session_lines.append(f"- [{t}] {c}")
    if session_lines:
        sp = f"sessions/{TODAY}.md"
        append(sp, f"\\n## {NOW}\\n" + "\\n".join(session_lines) + "\\n")
        touched.add(sp)
    return touched

if __name__ == "__main__":
    import sys, json
    items = json.load(sys.stdin) if not sys.stdin.isatty() else []
    print("updated:", sorted(extract(items)))
'''

FILES["tools/state_engine.py"] = '''#!/usr/bin/env python3
"""状态更新器：刷新 runtime.md 的"最近更新时间"，确保状态文件存在。"""
import os
import re
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOW = datetime.now().strftime("%Y-%m-%d %H:%M")

def touch_runtime():
    path = os.path.join(ROOT, "state/runtime.md")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        txt = f.read()
    if "## 最近更新时间" in txt:
        txt = re.sub(r"(## 最近更新时间\\n- ).*", rf"\\g<1>{NOW}", txt, count=1)
    else:
        txt += f"\\n## 最近更新时间\\n- {NOW}\\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(txt)

if __name__ == "__main__":
    touch_runtime()
    print(f"state updated @ {NOW}")
'''

FILES["tools/sync.py"] = '''#!/usr/bin/env python3
"""Git 同步器：pull --rebase 优先，冲突则中止提示。"""
import subprocess
import sys
from datetime import datetime

def run(cmd, check=True):
    print("+", " ".join(cmd))
    return subprocess.run(cmd, capture_output=True, text=True)

def main():
    # 无变更也不报错
    status = run(["git", "status", "--porcelain"])
    # 检测是否已配置上游远程
    has_upstream = run(["git", "rev-parse", "--abbrev-ref",
                        "--symbolic-full-name", "@{u}"]).returncode == 0
    if has_upstream:
        pull = run(["git", "pull", "--rebase"])
        print(pull.stdout, pull.stderr)
        if "CONFLICT" in (pull.stdout + pull.stderr):
            print("\\n⚠️  拉取时发生冲突，已中止自动提交。请手动解决：")
            print("   git status → 编辑冲突文件 → git add → git rebase --continue → git push")
            sys.exit(1)
        if pull.returncode != 0:
            print("\\n⚠️  git pull 失败（非冲突），已中止。请检查网络/远程后重试。")
            sys.exit(1)
    else:
        print("（尚未配置上游远程，跳过 pull；请配置 origin 后 push。）")

    if not status.stdout.strip():
        print("无本地变更，跳过提交。")
        # 仍尝试 push（可能本地领先远端）
        run(["git", "push"])
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    run(["git", "add", "."])
    run(["git", "commit", "-m", f"codex auto sync: {ts}"])
    push = run(["git", "push"])
    print(push.stdout, push.stderr)
    if push.returncode != 0:
        print("⚠️  push 失败，请检查远程仓库与网络。")
        sys.exit(1)
    print("✅ 同步完成。")

if __name__ == "__main__":
    main()
'''

FILES["tools/run.py"] = '''#!/usr/bin/env python3
"""主入口：检查结构 → 读上下文 → (可选)解析对话落盘 → 更新状态 → (可选)同步。"""
import argparse
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

import chat_parser
import memory_extractor
import state_engine

CONTEXT = ["prompts", "memory", "state", "decisions"]

def ensure_structure():
    missing = [d for d in CONTEXT + ["sessions", "tools"]
               if not os.path.isdir(os.path.join(ROOT, d))]
    if missing:
        print("缺少目录:", missing, "→ 请先运行 python tools/init_project.py")
        sys.exit(1)

def load_context():
    print("== 加载上下文 ==")
    for d in ["prompts", "memory", "state", "decisions"]:
        p = os.path.join(ROOT, d)
        if os.path.isdir(p):
            for fn in sorted(os.listdir(p)):
                if fn.endswith(".md"):
                    print(f"  read {d}/{fn}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", help="直接传入对话内容")
    ap.add_argument("--file", help="从文件读入对话内容")
    ap.add_argument("--sync", action="store_true", help="结束后执行 git 同步")
    args = ap.parse_args()

    ensure_structure()
    load_context()

    text = ""
    if args.input:
        text = args.input
    elif args.file:
        with open(args.file, encoding="utf-8") as f:
            text = f.read()

    if text.strip():
        items = chat_parser.parse(text)
        touched = memory_extractor.extract(items)
        print("== 落盘 ==", sorted(touched))

    state_engine.touch_runtime()
    print("== 状态已更新 ==")

    if args.sync:
        subprocess.run([sys.executable, os.path.join(ROOT, "tools", "sync.py")])

if __name__ == "__main__":
    main()
'''

FILES["tools/install_hooks.sh"] = '''#!/bin/bash
# 安装 git hooks（防递归：仅在有已暂存变更时运行状态刷新）
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOKS="$ROOT/.git/hooks"

if [ ! -d "$ROOT/.git" ]; then
  echo "未检测到 .git，请先 git init。"
  exit 1
fi

cat > "$HOOKS/pre-commit" <<'EOF'
#!/bin/bash
# 若无已暂存变更则跳过，避免递归
if git diff --cached --quiet; then
  exit 0
fi
python tools/state_engine.py >/dev/null 2>&1 || true
# 若 state_engine 改动了 runtime.md，纳入本次提交
git add state/runtime.md >/dev/null 2>&1 || true
EOF

cat > "$HOOKS/post-commit" <<'EOF'
#!/bin/bash
echo "Codex sync completed."
EOF

chmod +x "$HOOKS/pre-commit" "$HOOKS/post-commit"
echo "✅ hooks 已安装：pre-commit / post-commit"
'''

# init_project.py 本身也放进 tools/（自举）
with open(os.path.abspath(__file__), encoding="utf-8") as _f:
    FILES["tools/init_project.py"] = _f.read()

# ---------------------------------------------------------------------------
# 写入
# ---------------------------------------------------------------------------

def main():
    created, skipped = [], []
    for d in DIRS:
        os.makedirs(os.path.join(ROOT, d), exist_ok=True)

    for rel, content in FILES.items():
        full = os.path.join(ROOT, rel)
        os.makedirs(os.path.dirname(full) or ROOT, exist_ok=True)
        if os.path.exists(full) and not FORCE:
            skipped.append(rel)
            continue
        with open(full, "w", encoding="utf-8") as f:
            f.write(content)
        created.append(rel)
        if rel.endswith((".py", ".sh")):
            st = os.stat(full)
            os.chmod(full, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    print(f"根目录: {ROOT}\n")
    print("已创建:")
    for c in sorted(created):
        print("  +", c)
    if skipped:
        print("\n已跳过(已存在，用 --force 覆盖):")
        for s in sorted(skipped):
            print("  =", s)

    print("\n下一步：")
    print("  cd", ROOT)
    print("  git init && git add . && git commit -m 'init codex system'")
    print("  git remote add origin <your-repo-url>")
    print("  git branch -M main && git push -u origin main")
    print("  # 第二台 Mac: git clone <your-repo-url>")

if __name__ == "__main__":
    main()
