#!/usr/bin/env python3
"""状态更新器：刷新 runtime.md 的"最近更新时间"，确保状态文件存在。"""
import os
import re
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOW = datetime.now().strftime("%Y-%m-%d %H:%M")

def touch_runtime():
    path = os.path.join(ROOT, "state/runtime.md")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        txt = f.read()
    if "## 最近更新时间" in txt:
        txt = re.sub(r"(## 最近更新时间\n- ).*", rf"\g<1>{NOW}", txt, count=1)
    else:
        txt += f"\n## 最近更新时间\n- {NOW}\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(txt)

if __name__ == "__main__":
    touch_runtime()
    print(f"state updated @ {NOW}")
