#!/bin/bash
# 安装 git hooks（防递归：仅在有已暂存变更时运行状态刷新）
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOKS="$ROOT/.git/hooks"

if [ ! -d "$ROOT/.git" ]; then
  echo "未检测到 .git，请先 git init。"
  exit 1
fi

cat > "$HOOKS/pre-commit" <<'EOF'
#!/bin/bash
# 若无已暂存变更则跳过，避免递归
if git diff --cached --quiet; then
  exit 0
fi
python tools/state_engine.py >/dev/null 2>&1 || true
# 若 state_engine 改动了 runtime.md，纳入本次提交
git add state/runtime.md >/dev/null 2>&1 || true
EOF

cat > "$HOOKS/post-commit" <<'EOF'
#!/bin/bash
echo "Codex sync completed."
EOF

chmod +x "$HOOKS/pre-commit" "$HOOKS/post-commit"
echo "✅ hooks 已安装：pre-commit / post-commit"
