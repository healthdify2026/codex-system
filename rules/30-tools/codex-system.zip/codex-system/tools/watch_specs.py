#!/usr/bin/env python3
"""
watch_specs.py — 监听 specs/ 目录，发现新 SPEC 自动开跑。

行为：
  - 每 INTERVAL 秒扫描 specs/*.md（排除 SPEC.template.md、README.md）。
  - 对每个「未处理过」或「内容有变」的 SPEC，调用 orchestrator.py。
  - 已处理记录写入 state/.processed_specs.json（哈希 + 判定），避免重复跑。
  - PASS/ESCALATE 都记录；ESCALATE 的会在日志里高亮，等你抽查。

纯标准库、轮询实现（不依赖 watchdog），可在任意 mac 上直接跑。

用法：
  python3 tools/watch_specs.py                    # 前台运行，默认 workspace-write
  python3 tools/watch_specs.py --sandbox read-only
  python3 tools/watch_specs.py --once             # 只扫一次就退出（可配合 cron）
  python3 tools/watch_specs.py --interval 30

后台常驻可用 nohup 或 launchd（见 docs/）。
"""

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPECS = os.path.join(ROOT, "specs")
STATE = os.path.join(ROOT, "state", ".processed_specs.json")
ORCH = os.path.join(ROOT, "tools", "orchestrator.py")
IGNORE = {"SPEC.template.md", "README.md"}


def load_state():
    try:
        with open(STATE, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_state(state):
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    with open(STATE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def file_hash(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()[:16]


def scan_once(sandbox):
    if not os.path.isdir(SPECS):
        print("specs/ 不存在", file=sys.stderr)
        return
    state = load_state()
    for fn in sorted(os.listdir(SPECS)):
        if not fn.endswith(".md") or fn in IGNORE:
            continue
        path = os.path.join(SPECS, fn)
        h = file_hash(path)
        prev = state.get(fn, {})
        if prev.get("hash") == h and prev.get("verdict") in ("PASS", "ESCALATE"):
            continue  # 已处理且内容未变，跳过
        print(f"🚀 发现待处理 SPEC：{fn} → 开跑", file=sys.stderr)
        r = subprocess.run([sys.executable, ORCH, path, "--sandbox", sandbox])
        verdict = "PASS" if r.returncode == 0 else "CHECK"
        # 从 reviews 里读回真实判定（PASS/RETRY/ESCALATE）
        rv_path = os.path.join(ROOT, "reviews", fn)
        if os.path.exists(rv_path):
            txt = open(rv_path, encoding="utf-8").read()
            for v in ("PASS", "ESCALATE", "RETRY"):
                if f"判定：**{v}**" in txt:
                    verdict = v
                    break
        state[fn] = {"hash": h, "verdict": verdict, "ts": time.strftime("%Y-%m-%d %H:%M")}
        save_state(state)
        if verdict == "ESCALATE":
            print(f"⚠️  {fn} 需人工抽查：reviews/{fn}", file=sys.stderr)
        else:
            print(f"✅ {fn} → {verdict}", file=sys.stderr)


def main():
    ap = argparse.ArgumentParser(description="监听 specs/ 自动执行")
    ap.add_argument("--sandbox", default="workspace-write",
                    choices=["read-only", "workspace-write", "danger-full-access"])
    ap.add_argument("--interval", type=int, default=20, help="轮询间隔秒")
    ap.add_argument("--once", action="store_true", help="只扫一次即退出")
    args = ap.parse_args()

    if args.once:
        scan_once(args.sandbox)
        return
    print(f"👀 监听 {SPECS}（每 {args.interval}s，sandbox={args.sandbox}）Ctrl-C 退出",
          file=sys.stderr)
    try:
        while True:
            scan_once(args.sandbox)
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n停止监听。", file=sys.stderr)


if __name__ == "__main__":
    main()
