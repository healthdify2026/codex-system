#!/usr/bin/env python3
"""
orchestrator.py — 无人值守执行一个 SPEC。

流程（对应你的选择：自动+抽查）：
  1. 读 specs/<ID>.md
  2. codex exec 执行任务（按 SPEC，含约束）
  3. codex exec 自审：对照 SPEC 的验收 checklist 逐条打分，输出结构化 JSON
  4. 全部通过 → 写 reviews/<ID>.md（含 verdict=PASS）→ 调 sync.py
     有未过  → 写 reviews/<ID>.md（verdict=RETRY + 具体条目）→ 回喂 Codex 重做
  5. 超过 MAX_RETRY 仍不过 → 标记 verdict=ESCALATE，停手，留档等你抽查

设计原则：
  - 机器自审自过是默认路径；ESCALATE 是唯一需要人介入的出口。
  - 所有产出落盘到 reviews/，你可随时 git pull 抽查。
  - Codex 无实时通道联系 Claude；"审核"由第二次 codex exec 扮演审核 agent 完成。

依赖：codex CLI 已安装并登录（或设置 CODEX_API_KEY）。纯标准库。

用法：
  python3 tools/orchestrator.py specs/2026-07-02-sync-dryrun.md
  python3 tools/orchestrator.py --sandbox read-only specs/<ID>.md
"""

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAX_RETRY = 2  # 打回后最多自动重做次数；仍不过则 ESCALATE

# ---------------------------------------------------------------------------
# Sandbox 权限级别说明（--sandbox 取值），你按任务风险自行选择：
#
#   read-only        只读。Codex 能读仓库、能"建议"，但不写任何文件。
#                    最保守。适合分析、审查、生成方案类任务。
#
#   workspace-write  可读写「当前工作区(git 仓库)」内的文件，不碰仓库外、
#                    默认也不联网。适合绝大多数写代码/改文件的任务。★推荐默认
#
#   danger-full-access  去掉所有沙箱：可碰任意文件、可联网、可跑任意命令。
#                    仅在隔离容器/CI runner 里用。本地日常不要用。
#
# 本脚本默认 workspace-write。用 --sandbox 覆盖。
# ---------------------------------------------------------------------------
DEFAULT_SANDBOX = "workspace-write"

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "items": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "n": {"type": "integer"},
                    "point": {"type": "string"},
                    "result": {"type": "string", "enum": ["pass", "fail", "na"]},
                    "evidence": {"type": "string"},
                },
                "required": ["n", "point", "result", "evidence"],
                "additionalProperties": False,
            },
        },
        "changed_files": {"type": "array", "items": {"type": "string"}},
        "deviations": {"type": "string"},
        "overall": {"type": "string", "enum": ["pass", "fail"]},
    },
    "required": ["items", "changed_files", "deviations", "overall"],
    "additionalProperties": False,
}


def run_codex(prompt, sandbox, json_mode=False, schema_path=None, cwd=ROOT):
    cmd = ["codex", "exec", "--sandbox", sandbox]
    if json_mode:
        cmd.append("--json")
    if schema_path:
        cmd += ["--output-schema", schema_path]
    cmd.append(prompt)
    print("+", " ".join(cmd[:5]), "...[prompt]", file=sys.stderr)
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


def extract_final_json(stdout):
    """从 --json 的 JSONL 事件流里取最后一条 agent 消息文本，再解析成 JSON。"""
    text = None
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        # 兼容不同事件命名：取带 text 的 agent 消息
        item = ev.get("item") or ev.get("params", {}).get("item") or {}
        if item.get("type") in ("agent_message", "agentMessage") and item.get("text"):
            text = item["text"]
        if isinstance(ev.get("params", {}).get("delta"), str):
            text = (text or "") + ev["params"]["delta"]
    if not text:
        return None
    # 去掉可能的 ```json 围栏
    text = re.sub(r"^```json\s*|\s*```$", "", text.strip())
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def task_id_from_spec(spec_path):
    base = os.path.basename(spec_path)
    return re.sub(r"\.md$", "", base)


def build_exec_prompt(spec_text, retry_feedback=None):
    p = f"""你是执行者 Codex。严格按下面的 SPEC 执行任务。
只做「范围内」，不碰「范围外」，遵守「约束」。与既有 decisions/ 冲突时停下并在最后说明，不擅自扩张。
完成后照常更新 state/runtime.md，关键决策写 decisions/。

===== SPEC =====
{spec_text}
================
"""
    if retry_feedback:
        p += f"""
上一轮审核未通过，必须修复以下问题后重新完成：
{retry_feedback}
"""
    return p


def build_review_prompt(spec_text, task_id):
    return f"""你是审核者。对照下面 SPEC 的「验收 checklist」，检查当前仓库工作区的实际状态，
逐条判定 pass/fail/na，给出证据（引用文件/命令输出）。再给 changed_files（git diff 涉及的文件）、
deviations（范围外改动或与决策冲突，无则写"无"）、overall（全部关键项 pass 才算 pass）。
只输出符合 schema 的 JSON，不要额外文字。

任务ID：{task_id}
===== SPEC =====
{spec_text}
================
"""


def write_review(task_id, review_json, verdict, retry_feedback=None):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    path = os.path.join(ROOT, "reviews", f"{task_id}.md")
    lines = [f"# REVIEW — {task_id}", "", f"- 执行时间：{ts}",
             f"- 判定：**{verdict}**", ""]
    if review_json:
        lines += ["## 自审逐条", "", "| # | 验收点 | 结果 | 证据 |",
                  "|---|---|---|---|"]
        for it in review_json.get("items", []):
            r = {"pass": "✅", "fail": "❌", "na": "➖"}.get(it.get("result"), "?")
            ev = str(it.get("evidence", "")).replace("|", "/").replace("\n", " ")
            pt = str(it.get("point", "")).replace("|", "/")
            lines.append(f"| {it.get('n')} | {pt} | {r} | {ev} |")
        lines += ["", "### 改动文件",
                  *[f"- {f}" for f in review_json.get("changed_files", [])],
                  "", f"### 偏离与疑问", review_json.get("deviations", "无"), ""]
    if retry_feedback:
        lines += ["## 打回原因", retry_feedback, ""]
    if verdict == "ESCALATE":
        lines += ["## ⚠️ 需人工抽查",
                  "机器自动重试已达上限仍未通过，已停手。请 git pull 后人工复核本单与 diff。", ""]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path


def failed_items_feedback(review_json):
    if not review_json:
        return "审核未能产出结构化结果，请检查执行是否完成。"
    fails = [it for it in review_json.get("items", []) if it.get("result") == "fail"]
    if not fails:
        return ""
    return "\n".join(f"- checklist 第 {it['n']} 条未满足：{it.get('point','')}"
                     f"（证据：{it.get('evidence','')}）" for it in fails)


def orchestrate(spec_path, sandbox):
    task_id = task_id_from_spec(spec_path)
    with open(spec_path, encoding="utf-8") as f:
        spec_text = f.read()

    schema_path = os.path.join(ROOT, "tools", ".review_schema.json")
    with open(schema_path, "w", encoding="utf-8") as f:
        json.dump(REVIEW_SCHEMA, f)

    feedback = None
    for attempt in range(1, MAX_RETRY + 2):  # 1 次首跑 + MAX_RETRY 次重试
        print(f"=== [{task_id}] 执行 attempt {attempt} (sandbox={sandbox}) ===",
              file=sys.stderr)
        ex = run_codex(build_exec_prompt(spec_text, feedback), sandbox)
        if ex.returncode != 0:
            print("codex exec 执行失败：", ex.stderr[-500:], file=sys.stderr)
            write_review(task_id, None, "ESCALATE",
                         f"codex exec 非零退出：{ex.stderr[-300:]}")
            return "ESCALATE"

        print(f"=== [{task_id}] 自审 attempt {attempt} ===", file=sys.stderr)
        rv = run_codex(build_review_prompt(spec_text, task_id), sandbox,
                       json_mode=True, schema_path=schema_path)
        review_json = extract_final_json(rv.stdout)

        if review_json and review_json.get("overall") == "pass":
            write_review(task_id, review_json, "PASS")
            print(f"=== [{task_id}] PASS，执行同步 ===", file=sys.stderr)
            subprocess.run([sys.executable, os.path.join(ROOT, "tools", "sync.py")])
            return "PASS"

        feedback = failed_items_feedback(review_json)
        write_review(task_id, review_json, "RETRY", feedback)
        print(f"=== [{task_id}] 未通过，准备重试 ===", file=sys.stderr)

    # 用尽重试
    write_review(task_id, review_json, "ESCALATE", feedback)
    print(f"=== [{task_id}] 达重试上限，ESCALATE，等待人工抽查 ===", file=sys.stderr)
    return "ESCALATE"


def main():
    ap = argparse.ArgumentParser(description="无人值守执行一个 SPEC")
    ap.add_argument("spec", help="specs/<ID>.md 路径")
    ap.add_argument("--sandbox", default=DEFAULT_SANDBOX,
                    choices=["read-only", "workspace-write", "danger-full-access"],
                    help="Codex 权限级别，见脚本顶部注释")
    args = ap.parse_args()
    if not os.path.exists(args.spec):
        print("找不到 SPEC：", args.spec, file=sys.stderr)
        sys.exit(2)
    verdict = orchestrate(args.spec, args.sandbox)
    sys.exit(0 if verdict == "PASS" else 1)


if __name__ == "__main__":
    main()
