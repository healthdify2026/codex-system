#!/usr/bin/env python3
"""对话解析器：把一段文本按启发式规则切分为结构化条目。"""
import re

RULES = [
    ("DECISION",  ["决定", "确定", "采用", "选择", "以后统一", "后续都"]),
    ("BLOCKER",   ["问题", "阻塞", "风险", "报错", "失败"]),
    ("TRADEOFF",  ["原因", "取舍", "权衡", "优缺点"]),
    ("PROGRESS",  ["完成", "进度", "已实现", "还没做"]),
    ("PREFERENCE",["偏好", "希望", "默认", "风格"]),
    ("TASK",      ["当前", "正在", "这次", "下一步", "待办", "任务"]),
]

def classify(line: str) -> str:
    for label, kws in RULES:
        if any(k in line for k in kws):
            return label
    return "FACT"

def parse(text: str):
    items = []
    for raw in re.split(r"[\n。；;]", text):
        s = raw.strip()
        if not s:
            continue
        items.append({"type": classify(s), "content": s})
    return items

if __name__ == "__main__":
    import sys, json
    data = sys.stdin.read() if not sys.stdin.isatty() else ""
    print(json.dumps(parse(data), ensure_ascii=False, indent=2))
