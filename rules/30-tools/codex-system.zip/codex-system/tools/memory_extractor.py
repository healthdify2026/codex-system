#!/usr/bin/env python3
"""记忆提取器：将解析结果追加写入对应文件（带时间戳）。"""
import os
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOW = datetime.now().strftime("%Y-%m-%d %H:%M")
TODAY = datetime.now().strftime("%Y-%m-%d")

TARGET = {
    "FACT":       "memory/global.md",
    "PREFERENCE": "memory/user-preferences.md",
    "DECISION":   "decisions/architecture.md",
    "TRADEOFF":   "decisions/tradeoffs.md",
    "PROGRESS":   "state/progress.md",
    "BLOCKER":    "state/runtime.md",
    "TASK":       "state/tasks.md",
}

def append(path: str, block: str):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "a", encoding="utf-8") as f:
        f.write(block)

def extract(items):
    touched = set()
    session_lines = []
    for it in items:
        t, c = it["type"], it["content"]
        path = TARGET.get(t, "memory/global.md")
        append(path, f"\n## {NOW}\n- 类型：{t}\n- 内容：{c}\n")
        touched.add(path)
        session_lines.append(f"- [{t}] {c}")
    if session_lines:
        sp = f"sessions/{TODAY}.md"
        append(sp, f"\n## {NOW}\n" + "\n".join(session_lines) + "\n")
        touched.add(sp)
    return touched

if __name__ == "__main__":
    import sys, json
    items = json.load(sys.stdin) if not sys.stdin.isatty() else []
    print("updated:", sorted(extract(items)))
