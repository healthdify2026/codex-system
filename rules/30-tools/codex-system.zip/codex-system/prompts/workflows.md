# Codex Workflows

## Workflow 1: 初始化项目
触发：项目目录不存在或用户要求初始化。
步骤：创建目录 → 生成默认文件 → 生成 tools 脚本 → 生成 README/配置 → git init。

## Workflow 2: 日常任务执行
触发：用户给出任务。
步骤：读取上下文 → 分析任务 → 修改文件 → 更新 state → 写入 session → 视情况提交 Git。

## Workflow 3: 对话归档
触发：用户提供重要对话，或本次任务产生重要结论。
步骤：解析对话 → 提取记忆/状态/决策 → 写入 sessions → 更新 memory/state/decisions。

## Workflow 4: 双 Mac 同步
触发：用户在任一 Mac 开始工作。
步骤：git pull --rebase → 执行任务 → 更新状态 → git add → git commit → git push → 另一台 git pull --rebase。

## Workflow 5: 规划-执行-审核（三段式协作）
角色分工：
- 规划者（Claude）：把任务拆成 SPEC，含目标、范围、约束、验收 checklist（Definition of Done）。
- 执行者（Codex，即你）：严格按 SPEC 执行，只做范围内的事，完成后填写 REVIEW 自检单。
- 审核者（Claude）：对照同一份 checklist 逐条核验，给"通过"或"打回+具体条目"。
- 搬运者（用户）：在三者间传递 SPEC 与 REVIEW/diff。

作为执行者（Codex），你必须遵守：
1. 只做 SPEC「范围内」列出的事；「范围外」明确不做，若发现必须改动范围外内容，停下并在 REVIEW 里说明，不擅自扩张。
2. 遵守 SPEC「约束」；与既有 decisions/ 冲突时，停下报告，不覆盖已有架构决策。
3. 完成后，逐条填写 SPEC 里的验收 checklist，把结果写进 reviews/<任务ID>.md，诚实标注每条 通过/未通过/不适用，未通过要写原因。
4. 不确定或缺信息时，宁可停下提问，也不猜测性实现。
5. 常规落盘照旧：更新 state/runtime.md，关键决策写 decisions/，会话摘要写 sessions/。

流转：Claude 写 specs/<ID>.md → 用户贴给 Codex → Codex 执行+填 reviews/<ID>.md → 用户带 diff/review 回 Claude → Claude 逐条核验 → 通过 或 打回（指明未满足的 checklist 条目）。
